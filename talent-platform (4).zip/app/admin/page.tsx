"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Upload,
  BarChart3,
  Settings,
  FileText,
  QrCode,
  Shield,
  TrendingUp,
  CheckCircle,
  PieChart,
  LineChartIcon,
} from "lucide-react"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"

const calculateStdDev = (values: number[]) => {
  const avg = values.reduce((a, b) => a + b, 0) / values.length
  const variance = values.reduce((sum, val) => sum + Math.pow(val - avg, 2), 0) / values.length
  return Math.round(Math.sqrt(variance) * 10) / 10
}

export default function AdminPanel() {
  const [uploadProgress, setUploadProgress] = useState(0)
  const [isUploading, setIsUploading] = useState(false)
  const [uploadedFile, setUploadedFile] = useState<File | null>(null)
  const [analysisResults, setAnalysisResults] = useState<any>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)

  const handleFileUpload = async (e: React.FormEvent) => {
    e.preventDefault()
    const formData = new FormData(e.target as HTMLFormElement)
    const file = formData.get("dataFile") as File

    if (!file) {
      alert("Please select a file")
      return
    }

    setUploadedFile(file)
    setIsUploading(true)
    setUploadProgress(0)

    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setIsUploading(false)
          analyzeUploadedData(file)
          return 100
        }
        return prev + 10
      })
    }, 200)
  }

  const analyzeUploadedData = async (file: File) => {
    setIsAnalyzing(true)

    try {
      const text = await file.text()
      let data: any[] = []

      if (file.name.endsWith(".csv")) {
        const lines = text.split("\n")
        const headers = lines[0].split(",").map((h) => h.trim())
        data = lines
          .slice(1)
          .filter((line) => line.trim())
          .map((line) => {
            const values = line.split(",").map((v) => v.trim())
            const obj: any = {}
            headers.forEach((header, index) => {
              obj[header] = values[index] || ""
            })
            return obj
          })
      } else if (file.name.endsWith(".json")) {
        data = JSON.parse(text)
      }

      const roleRecommendations = data.map((record: any) => {
        const coding = Number.parseInt(record.Coding) || 0
        const speaking = Number.parseInt(record.Speaking) || 0
        const logical = Number.parseInt(record.Logical) || 0
        const personality = Number.parseInt(record.Personality) || 0

        let recommendedRole = "General"
        if (coding > 85 && logical > 80) recommendedRole = "Backend Developer"
        else if (coding > 80 && personality > 85) recommendedRole = "Full Stack Developer"
        else if (speaking > 85 && personality > 85) recommendedRole = "Product Manager"
        else if (logical > 85 && speaking > 75) recommendedRole = "Data Analyst"
        else if (coding > 75 && speaking > 80) recommendedRole = "Technical Lead"

        return {
          ...record,
          recommendedRole,
          overallScore: Math.round((coding + speaking + logical + personality) / 4),
        }
      })

      const skillDistribution = {
        coding: roleRecommendations.reduce((sum, r) => sum + (Number.parseInt(r.Coding) || 0), 0) / data.length,
        speaking: roleRecommendations.reduce((sum, r) => sum + (Number.parseInt(r.Speaking) || 0), 0) / data.length,
        logical: roleRecommendations.reduce((sum, r) => sum + (Number.parseInt(r.Logical) || 0), 0) / data.length,
        personality:
          roleRecommendations.reduce((sum, r) => sum + (Number.parseInt(r.Personality) || 0), 0) / data.length,
      }

      const roleDistribution = roleRecommendations.reduce((acc: any, record: any) => {
        acc[record.recommendedRole] = (acc[record.recommendedRole] || 0) + 1
        return acc
      }, {})

      const collegePerformance = roleRecommendations.reduce((acc: any, record: any) => {
        if (!acc[record.College]) {
          acc[record.College] = { count: 0, totalScore: 0 }
        }
        acc[record.College].count += 1
        acc[record.College].totalScore += record.overallScore
        return acc
      }, {})

      const analysis = {
        totalRecords: data.length,
        averageScores: skillDistribution,
        topPerformers: roleRecommendations.sort((a, b) => b.overallScore - a.overallScore).slice(0, 5),
        roleDistribution: Object.entries(roleDistribution).map(([role, count]) => ({
          name: role,
          value: count,
        })),
        skillChartData: [
          { name: "Coding", value: Math.round(skillDistribution.coding) },
          { name: "Speaking", value: Math.round(skillDistribution.speaking) },
          { name: "Logical", value: Math.round(skillDistribution.logical) },
          { name: "Personality", value: Math.round(skillDistribution.personality) },
        ],
        collegePerformance: Object.entries(collegePerformance)
          .map(([college, data]: any) => ({
            name: college,
            avgScore: Math.round(data.totalScore / data.count),
            count: data.count,
          }))
          .sort((a, b) => b.avgScore - a.avgScore)
          .slice(0, 8),
        experienceDistribution: data.reduce((acc: any, record) => {
          acc[record.Experience] = (acc[record.Experience] || 0) + 1
          return acc
        }, {}),
        standardDeviation: {
          coding: calculateStdDev(roleRecommendations.map(r => Number.parseInt(r.Coding) || 0)),
          speaking: calculateStdDev(roleRecommendations.map(r => Number.parseInt(r.Speaking) || 0)),
          logical: calculateStdDev(roleRecommendations.map(r => Number.parseInt(r.Logical) || 0)),
          personality: calculateStdDev(roleRecommendations.map(r => Number.parseInt(r.Personality) || 0)),
          overall: calculateStdDev(roleRecommendations.map(r => r.overallScore)),
        },
        scoreDistribution: (() => {
          const ranges = [
            { range: "0-20", min: 0, max: 20, count: 0 },
            { range: "21-40", min: 21, max: 40, count: 0 },
            { range: "41-60", min: 41, max: 60, count: 0 },
            { range: "61-80", min: 61, max: 80, count: 0 },
            { range: "81-100", min: 81, max: 100, count: 0 },
          ]
          roleRecommendations.forEach(r => {
            const score = r.overallScore
            ranges.forEach(range => {
              if (score >= range.min && score <= range.max) range.count++
            })
          })
          return ranges
        })(),
        skillConsistency: roleRecommendations.map(r => {
          const scores = [
            Number.parseInt(r.Coding) || 0,
            Number.parseInt(r.Speaking) || 0,
            Number.parseInt(r.Logical) || 0,
            Number.parseInt(r.Personality) || 0
          ]
          const avg = scores.reduce((a, b) => a + b, 0) / scores.length
          const variance = scores.reduce((sum, score) => sum + Math.pow(score - avg, 2), 0) / scores.length
          return {
            name: r.Name,
            consistency: Math.round(100 - Math.sqrt(variance)),
            overallScore: r.overallScore
          }
        }).sort((a, b) => b.consistency - a.consistency).slice(0, 5),
        performanceQuartiles: (() => {
          const sorted = [...roleRecommendations].sort((a, b) => a.overallScore - b.overallScore)
          const q1Index = Math.floor(sorted.length * 0.25)
          const q2Index = Math.floor(sorted.length * 0.5)
          const q3Index = Math.floor(sorted.length * 0.75)
          
          return {
            q1: sorted[q1Index]?.overallScore || 0,
            median: sorted[q2Index]?.overallScore || 0,
            q3: sorted[q3Index]?.overallScore || 0,
            iqr: (sorted[q3Index]?.overallScore || 0) - (sorted[q1Index]?.overallScore || 0),
          }
        })(),
        skillBalance: (() => {
          const balanced = roleRecommendations.filter(r => {
            const scores = [
              Number.parseInt(r.Coding) || 0,
              Number.parseInt(r.Speaking) || 0,
              Number.parseInt(r.Logical) || 0,
              Number.parseInt(r.Personality) || 0
            ]
            const max = Math.max(...scores)
            const min = Math.min(...scores)
            return (max - min) < 20
          }).length
          
          return {
            balanced: balanced,
            specialized: data.length - balanced,
            balancedPercent: Math.round((balanced / data.length) * 100)
          }
        })(),
      }

      setAnalysisResults(analysis)
    } catch (error) {
      console.error("Error analyzing data:", error)
      alert("Error analyzing data. Please check file format.")
    } finally {
      setIsAnalyzing(false)
    }
  }

  const generateSkillCards = () => {
    setIsUploading(true)
    setUploadProgress(0)

    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setIsUploading(false)
          const link = document.createElement("a")
          link.href = "data:text/plain;charset=utf-8,Skill cards generated successfully!"
          link.download = "skill-cards.zip"
          link.click()
          alert("Skill cards generated and downloaded successfully!")
          return 100
        }
        return prev + 10
      })
    }, 100)
  }

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault()
    const formData = new FormData(e.target as HTMLFormElement)
    const settings = {
      platformName: formData.get("platformName"),
      tagline: formData.get("tagline"),
      description: formData.get("description"),
    }
    console.log("Saving settings:", settings)
    alert("Settings saved successfully!")
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 right-20 w-64 h-64 bg-primary/10 rounded-full blur-3xl animate-float"></div>
        <div
          className="absolute bottom-20 left-20 w-64 h-64 bg-accent/10 rounded-full blur-3xl animate-float"
          style={{ animationDelay: "2s" }}
        ></div>
      </div>

      <div className="relative z-10">
        <header className="glass-effect border-b border-primary/20 sticky top-0 z-50">
          <div className="container mx-auto px-4 py-4 flex flex-wrap gap-4 items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-8 h-8 bg-gradient-to-r from-primary to-accent rounded-lg flex items-center justify-center">
                <Shield className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-xl font-bold">TalentRank Admin</h1>
              <Badge className="bg-accent/20 text-accent border-accent/30">Administrator</Badge>
            </div>

            <div className="flex items-center space-x-4">
              <Button variant="outline" size="sm" onClick={() => (window.location.href = "/")}>
                Back to Platform
              </Button>
            </div>
          </div>
        </header>

        <div className="container mx-auto px-4 py-8">
          <Tabs defaultValue="upload" className="space-y-6">
            <TabsList className="flex flex-wrap gap-2 w-full lg:grid lg:w-fit lg:grid-cols-3 bg-muted/50">
              <TabsTrigger value="upload">Data Upload & Analytics</TabsTrigger>
              <TabsTrigger value="skillcards">Skill Cards</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>

            <TabsContent value="upload" className="space-y-6">
              <div className="grid lg:grid-cols-2 gap-6">
                <Card className="glass-effect border-primary/20">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Upload className="w-5 h-5 mr-2 text-primary" />
                      Upload Talent Data
                    </CardTitle>
                    <CardDescription>Upload CSV or JSON files with talent information</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <form onSubmit={handleFileUpload} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="dataFile">Select File</Label>
                        <Input
                          id="dataFile"
                          name="dataFile"
                          type="file"
                          accept=".csv,.json"
                          className="bg-background/50 border-primary/30 focus:border-primary"
                          required
                        />
                      </div>

                      {isUploading && (
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span>Processing...</span>
                            <span>{uploadProgress}%</span>
                          </div>
                          <Progress value={uploadProgress} className="h-2" />
                        </div>
                      )}

                      <Button type="submit" className="w-full bg-primary hover:bg-primary/90" disabled={isUploading}>
                        {isUploading ? "Processing..." : "Upload & Analyze"}
                      </Button>
                    </form>

                    {isAnalyzing && (
                      <div className="flex items-center justify-center py-4">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                        <span className="ml-2">Analyzing data...</span>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card className="glass-effect border-accent/20">
                  <CardHeader>
                    <CardTitle className="flex items-center text-accent">
                      <FileText className="w-5 h-5 mr-2" />
                      Data Format Requirements
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <h4 className="font-semibold">Required Fields:</h4>
                      <ul className="text-sm space-y-1 text-muted-foreground">
                        <li>• Name (string)</li>
                        <li>• College (string)</li>
                        <li>• Coding (0-100)</li>
                        <li>• Speaking (0-100)</li>
                        <li>• Logical (0-100)</li>
                        <li>• Personality (0-100)</li>
                        <li>• Experience (Fresher/Experienced)</li>
                      </ul>
                    </div>

                    <div className="p-3 bg-muted/30 rounded-lg">
                      <h5 className="font-medium text-sm mb-2">Sample CSV Format:</h5>
                      <code className="text-xs text-muted-foreground">
                        Name,College,Coding,Speaking,Logical,Personality,Experience
                        <br />
                        Akshay Kapoor,PSIT,85,78,92,88,Experienced
                      </code>
                    </div>
                  </CardContent>
                </Card>

                {!analysisResults ? (
                  <Card className="glass-effect border-primary/20">
                    <CardContent className="py-12">
                      <div className="text-center space-y-4">
                        <BarChart3 className="w-12 h-12 mx-auto text-muted-foreground" />
                        <h3 className="text-lg font-semibold">No Data Uploaded Yet</h3>
                        <p className="text-muted-foreground">Upload a CSV or JSON file to see analytics and insights</p>
                      </div>
                    </CardContent>
                  </Card>
                ) : (
                  <>
                    <div className="grid md:grid-cols-2 gap-6">
                      <Card className="glass-effect border-primary/20">
                        <CardHeader>
                          <CardTitle className="flex items-center">
                            <BarChart3 className="w-5 h-5 mr-2 text-primary" />
                            Skill Distribution
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <ResponsiveContainer width="100%" height={350}>
                            <BarChart data={analysisResults.skillChartData} margin={{ bottom: 50 }}>
                              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                              <XAxis 
                                dataKey="name" 
                                stroke="rgba(255,255,255,0.5)"
                                fontSize={11}
                                interval={0}
                                angle={-45}
                                textAnchor="end"
                                height={80}
                              />
                              <YAxis stroke="rgba(255,255,255,0.5)" />
                              <Tooltip
                                contentStyle={{
                                  backgroundColor: "rgba(30, 30, 40, 0.95)",
                                  border: "1px solid rgba(139, 92, 246, 0.5)",
                                  borderRadius: "8px",
                                  color: "#fff",
                                }}
                                cursor={{ fill: "rgba(139, 92, 246, 0.1)" }}
                              />
                              <Bar dataKey="value" fill="#8b5cf6" radius={[8, 8, 0, 0]} />
                            </BarChart>
                          </ResponsiveContainer>
                        </CardContent>
                      </Card>

                      <Card className="glass-effect border-accent/20">
                        <CardHeader>
                          <CardTitle className="flex items-center">
                            <PieChart className="w-5 h-5 mr-2 text-accent" />
                            Role Distribution (Bar Chart)
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <ResponsiveContainer width="100%" height={350}>
                            <BarChart data={analysisResults.roleDistribution} margin={{ bottom: 50 }}>
                              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                              <XAxis
                                dataKey="name"
                                stroke="rgba(255,255,255,0.5)"
                                angle={-45}
                                textAnchor="end"
                                height={100}
                                fontSize={11}
                                interval={0}
                              />
                              <YAxis stroke="rgba(255,255,255,0.5)" />
                              <Tooltip
                                contentStyle={{
                                  backgroundColor: "rgba(30, 30, 40, 0.95)",
                                  border: "1px solid rgba(236, 72, 153, 0.5)",
                                  borderRadius: "8px",
                                  color: "#fff",
                                }}
                                cursor={{ fill: "rgba(236, 72, 153, 0.1)" }}
                              />
                              <Bar dataKey="value" fill="#ec4899" radius={[8, 8, 0, 0]} />
                            </BarChart>
                          </ResponsiveContainer>
                        </CardContent>
                      </Card>
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                      <Card className="glass-effect border-primary/20">
                        <CardHeader>
                          <CardTitle className="flex items-center">
                            <BarChart3 className="w-5 h-5 mr-2 text-primary" />
                            Experience Distribution
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-4">
                            {Object.entries(analysisResults.experienceDistribution).map(([exp, count]: any) => (
                              <div key={exp} className="space-y-2">
                                <div className="flex justify-between text-sm">
                                  <span className="font-medium">{exp}</span>
                                  <span className="text-primary font-bold">{count}</span>
                                </div>
                                <Progress value={(count / analysisResults.totalRecords) * 100} className="h-2" />
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>

                      <Card className="glass-effect border-accent/20">
                        <CardHeader>
                          <CardTitle className="flex items-center">
                            <TrendingUp className="w-5 h-5 mr-2 text-accent" />
                            Skill Gap Analysis
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-4">
                            {analysisResults.skillChartData.map((skill: any) => {
                              const gap = 100 - skill.value
                              return (
                                <div key={skill.name} className="space-y-2">
                                  <div className="flex justify-between text-sm">
                                    <span className="font-medium">{skill.name}</span>
                                    <span className="text-accent">{skill.value}/100</span>
                                  </div>
                                  <Progress value={skill.value} className="h-2" />
                                  <div className="text-xs text-muted-foreground">Gap: {gap} points</div>
                                </div>
                              )
                            })}
                          </div>
                        </CardContent>
                      </Card>
                    </div>

                    <Card className="glass-effect border-primary/20">
                      <CardHeader>
                        <CardTitle className="flex items-center">
                          <TrendingUp className="w-5 h-5 mr-2 text-primary" />
                          Standard Deviation Analysis
                        </CardTitle>
                        <CardDescription>Measure of score variability (lower = more consistent)</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                          {Object.entries(analysisResults.standardDeviation).map(([skill, stdDev]: any) => (
                            <div key={skill} className="p-4 bg-muted/30 rounded-lg text-center">
                              <div className="text-sm text-muted-foreground capitalize mb-1">{skill}</div>
                              <div className="text-2xl font-bold text-primary">σ = {stdDev}</div>
                              <div className="text-xs text-muted-foreground mt-1">
                                {stdDev < 10 ? "Very Consistent" : stdDev < 15 ? "Consistent" : stdDev < 20 ? "Moderate" : "High Variance"}
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="glass-effect border-accent/20">
                      <CardHeader>
                        <CardTitle className="flex items-center">
                          <BarChart3 className="w-5 h-5 mr-2 text-accent" />
                          Overall Score Distribution
                        </CardTitle>
                        <CardDescription>Frequency distribution of candidate scores</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <ResponsiveContainer width="100%" height={300}>
                          <BarChart data={analysisResults.scoreDistribution}>
                            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                            <XAxis 
                              dataKey="range" 
                              stroke="rgba(255,255,255,0.5)"
                              fontSize={12}
                            />
                            <YAxis stroke="rgba(255,255,255,0.5)" />
                            <Tooltip
                              contentStyle={{
                                backgroundColor: "rgba(30, 30, 40, 0.95)",
                                border: "1px solid rgba(236, 72, 153, 0.5)",
                                borderRadius: "8px",
                                color: "#fff",
                              }}
                              cursor={{ fill: "rgba(236, 72, 153, 0.1)" }}
                            />
                            <Bar dataKey="count" fill="#ec4899" radius={[8, 8, 0, 0]} />
                          </BarChart>
                        </ResponsiveContainer>
                      </CardContent>
                    </Card>

                    <div className="grid md:grid-cols-2 gap-6">
                      <Card className="glass-effect border-primary/20">
                        <CardHeader>
                          <CardTitle className="flex items-center">
                            <CheckCircle className="w-5 h-5 mr-2 text-primary" />
                            Performance Quartiles
                          </CardTitle>
                          <CardDescription>Statistical distribution of scores</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-4">
                            <div className="flex justify-between items-center p-3 bg-muted/30 rounded-lg">
                              <span className="text-sm font-medium">Q1 (25th percentile)</span>
                              <span className="text-xl font-bold text-primary">{analysisResults.performanceQuartiles.q1}</span>
                            </div>
                            <div className="flex justify-between items-center p-3 bg-muted/30 rounded-lg">
                              <span className="text-sm font-medium">Median (50th percentile)</span>
                              <span className="text-xl font-bold text-accent">{analysisResults.performanceQuartiles.median}</span>
                            </div>
                            <div className="flex justify-between items-center p-3 bg-muted/30 rounded-lg">
                              <span className="text-sm font-medium">Q3 (75th percentile)</span>
                              <span className="text-xl font-bold text-primary">{analysisResults.performanceQuartiles.q3}</span>
                            </div>
                            <div className="flex justify-between items-center p-3 bg-accent/20 rounded-lg border border-accent/30">
                              <span className="text-sm font-medium">IQR (Interquartile Range)</span>
                              <span className="text-xl font-bold text-accent">{analysisResults.performanceQuartiles.iqr}</span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>

                      <Card className="glass-effect border-accent/20">
                        <CardHeader>
                          <CardTitle className="flex items-center">
                            <PieChart className="w-5 h-5 mr-2 text-accent" />
                            Skill Balance Index
                          </CardTitle>
                          <CardDescription>Balanced vs specialized talent distribution</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-4">
                            <div className="text-center py-4">
                              <div className="text-5xl font-bold text-accent mb-2">
                                {analysisResults.skillBalance.balancedPercent}%
                              </div>
                              <div className="text-sm text-muted-foreground">of candidates are balanced</div>
                            </div>
                            <div className="space-y-2">
                              <div className="flex justify-between text-sm">
                                <span className="font-medium">Balanced Skills</span>
                                <span className="text-accent font-bold">{analysisResults.skillBalance.balanced}</span>
                              </div>
                              <Progress value={(analysisResults.skillBalance.balanced / analysisResults.totalRecords) * 100} className="h-2" />
                            </div>
                            <div className="space-y-2">
                              <div className="flex justify-between text-sm">
                                <span className="font-medium">Specialized Skills</span>
                                <span className="text-primary font-bold">{analysisResults.skillBalance.specialized}</span>
                              </div>
                              <Progress value={(analysisResults.skillBalance.specialized / analysisResults.totalRecords) * 100} className="h-2" />
                            </div>
                            <div className="text-xs text-muted-foreground mt-2">
                              * Balanced: Skills differ by less than 20 points
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>

                    <Card className="glass-effect border-primary/20">
                      <CardHeader>
                        <CardTitle className="flex items-center">
                          <CheckCircle className="w-5 h-5 mr-2 text-primary" />
                          Most Consistent Performers
                        </CardTitle>
                        <CardDescription>Candidates with balanced skill profiles</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          {analysisResults.skillConsistency.map((performer: any, index: number) => (
                            <div key={index} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                              <div>
                                <div className="font-semibold">{performer.name}</div>
                                <div className="text-xs text-muted-foreground">Overall: {performer.overallScore}/100</div>
                              </div>
                              <div className="text-right">
                                <div className="text-lg font-bold text-primary">{performer.consistency}%</div>
                                <div className="text-xs text-muted-foreground">Consistency</div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="glass-effect border-primary/20">
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <LineChartIcon className="w-5 h-5 mr-2 text-primary" />
                        College Performance Analysis
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      {/* Increased height slightly for better label spacing */}
                      <ResponsiveContainer width="100%" height={350}> 
                        <BarChart 
                          data={analysisResults.collegePerformance}
                          margin={{ top: 5, right: 0, left: -20, bottom: 80 }} /* Adjust margins */
                         > 
                          {/* Fainter grid using border variable */}
                          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" opacity={0.3} /> 
                          <XAxis
                            dataKey="name"
                            stroke="var(--muted-foreground)" // Use theme color
                            angle={-45}
                            textAnchor="end"
                            height={100} // Increased height for longer names
                            interval={0} // Ensure all labels show
                            tick={{ fontSize: 10 }} // Smaller font size
                          />
                          <YAxis 
                            stroke="var(--muted-foreground)" // Use theme color
                            tick={{ fontSize: 11 }}
                            /* Added Y-Axis Label */
                            label={{ value: 'Score / Count', angle: -90, position: 'insideLeft', fill: 'var(--muted-foreground)', fontSize: 12, dx:-5 }} 
                          />
                          <Tooltip
                            contentStyle={{
                              backgroundColor: "var(--popover)", // Use theme variable
                              border: "1px solid var(--border)",   // Use theme variable
                              borderRadius: "var(--radius-md)", // Use theme variable
                              color: "var(--popover-foreground)", // Use theme variable
                              fontSize: "12px",
                              boxShadow: "0 4px 12px rgba(0,0,0,0.1)"
                            }}
                            cursor={{ fill: "var(--primary)", fillOpacity: 0.1 }} // Use theme color for cursor
                            itemStyle={{ color: "var(--popover-foreground)"}}
                            labelStyle={{ color: "var(--foreground)", fontWeight: "bold"}}
                          />
                          {/* Styled Legend */}
                          <Legend 
                             wrapperStyle={{ 
                               color: 'var(--muted-foreground)', 
                               fontSize: '12px',
                               paddingTop: '10px' // Add some space above legend
                             }} 
                             verticalAlign="top" // Move legend to top
                             align="right"
                           /> 
                           {/* Bars using theme colors and radius */}
                          <Bar dataKey="avgScore" fill="var(--accent)" name="Avg Score" radius={[4, 4, 0, 0]} /> 
                          <Bar dataKey="count" fill="var(--chart-3)" name="Count" radius={[4, 4, 0, 0]} /> 
                        </BarChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>

                    <Card className="glass-effect border-accent/20">
                      <CardHeader>
                        <CardTitle className="flex items-center text-accent">
                          <CheckCircle className="w-5 h-5 mr-2" />
                          Top Performers & Role Recommendations
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          {analysisResults.topPerformers.map((performer: any, index: number) => (
                            <div key={index} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                              <div>
                                <div className="font-semibold">{performer.Name}</div>
                                <div className="text-sm text-muted-foreground">{performer.College}</div>
                              </div>
                              <div className="text-right">
                                <Badge className="bg-accent/20 text-accent border-accent/30 mb-1">
                                  {performer.recommendedRole}
                                </Badge>
                                <div className="text-lg font-bold text-primary">{performer.overallScore}/100</div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </>
                )}
              </div>
            </TabsContent>

            <TabsContent value="skillcards" className="space-y-6">
              <Card className="glass-effect border-primary/20">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <QrCode className="w-5 h-5 mr-2 text-primary" />
                    Skill Cards
                  </CardTitle>
                  <CardDescription>Generate and download skill cards for talent assessment</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button
                    onClick={generateSkillCards}
                    className="w-full bg-primary hover:bg-primary/90"
                    disabled={isUploading}
                  >
                    {isUploading ? "Generating..." : "Generate Skill Cards"}
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="settings" className="space-y-6">
              <Card className="glass-effect border-primary/20">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Settings className="w-5 h-5 mr-2 text-primary" />
                    Platform Settings
                  </CardTitle>
                  <CardDescription>Configure platform settings and preferences</CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSaveSettings} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="platformName">Platform Name</Label>
                      <Input
                        id="platformName"
                        name="platformName"
                        type="text"
                        placeholder="TalentRank"
                        className="bg-background/50 border-primary/30 focus:border-primary"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="tagline">Tagline</Label>
                      <Input
                        id="tagline"
                        name="tagline"
                        type="text"
                        placeholder="Empowering talent discovery"
                        className="bg-background/50 border-primary/30 focus:border-primary"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="description">Description</Label>
                      <Textarea
                        id="description"
                        name="description"
                        placeholder="A platform for talent assessment and career development"
                        className="bg-background/50 border-primary/30 focus:border-primary"
                        rows={3}
                        required
                      />
                    </div>

                    <Button type="submit" className="w-full bg-primary hover:bg-primary/90">
                      Save Settings
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
